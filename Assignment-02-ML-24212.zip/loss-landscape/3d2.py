import argparse
import torch
import h5py
import numpy as np
import matplotlib.pyplot as plt
from torch.multiprocessing import Process, Queue
from utils import get_weights, set_weights, normalize_direction, get_random_directions
from utils import get_net, test_loss_acc
from dataloader import load_dataset


def compute_loss_surface_worker(queue, results, w, d1, d2, net, testloader, x_vals, y_vals):
    """Worker function to compute loss for a subset of the grid."""
    while not queue.empty():
        idx = queue.get()
        i = idx // len(y_vals)
        j = idx % len(y_vals)
        x = x_vals[i]
        y = y_vals[j]

        # Perturb weights
        w_perturbed = [w_k + x * d1_k + y * d2_k for w_k, d1_k, d2_k in zip(w, d1, d2)]
        set_weights(net, w_perturbed)

        # Compute loss
        criterion = torch.nn.CrossEntropyLoss()
        loss, _ = test_loss_acc(net, criterion, testloader)

        # Store result
        results[idx] = loss
        print(f"Loss at ({i}, {j}): {loss:.4f}")


def plot_surface(model_path, model_type='resnet56', dataset='cifar10', x_range=(-1, 1), y_range=(-1, 1), steps=51, num_workers=4):
    # Load model
    net = get_net(model_type, dataset, model_path)
    net.eval()

    # Get data loader
    from argparse import Namespace
    args = Namespace(
        dataset='cifar10',
        datapath='cifar10/data',
        batch_size=1024,
        threads=2,
        raw_data=False,
        data_split=1,
        split_idx=0,
        trainloader='',
        testloader='',
        ngpu=1
    )
    _, testloader = load_dataset(args.dataset, args.datapath,
                                 args.batch_size, args.threads,
                                 args.raw_data, args.data_split,
                                 args.split_idx, args.trainloader,
                                 args.testloader)

    # Get base weights
    w = get_weights(net)

    # Generate random directions
    d1, d2 = get_random_directions(w)
    d1 = normalize_direction(d1, w, ignore='biasbn', norm='filter')
    d2 = normalize_direction(d2, w, ignore='biasbn', norm='filter')

    # Prepare grid
    x_vals = np.linspace(x_range[0], x_range[1], steps)
    y_vals = np.linspace(y_range[0], y_range[1], steps)
    loss_surface = np.zeros((steps, steps))

    # Create a queue and distribute tasks
    queue = Queue()
    for idx in range(steps * steps):
        queue.put(idx)

    # Shared dictionary to store results
    results = torch.multiprocessing.Manager().dict()

    # Spawn processes
    processes = []
    for _ in range(num_workers):
        p = Process(target=compute_loss_surface_worker, args=(queue, results, w, d1, d2, net, testloader, x_vals, y_vals))
        p.start()
        processes.append(p)

    # Wait for all processes to finish
    for p in processes:
        p.join()

    # Fill the loss surface with results
    for idx, loss in results.items():
        i = idx // steps
        j = idx % steps
        loss_surface[j, i] = loss

    # Save and plot
    np.save('loss_surface.npy', loss_surface)
    plot_contour_surface(x_vals, y_vals, loss_surface)


model_type = ""
def plot_contour_surface(x_vals, y_vals, Z):
    X, Y = np.meshgrid(x_vals, y_vals)

    # 3D Surface
    fig = plt.figure(figsize=(14, 6))
    ax = fig.add_subplot(121, projection='3d')
    ax.plot_surface(X, Y, Z, cmap='viridis')
    ax.set_title("3D Loss Surface")
    ax.set_xlabel("Direction 1")
    ax.set_ylabel("Direction 2")
    ax.set_zlabel("Loss")

    # Contour
    ax2 = fig.add_subplot(122)
    contour = ax2.contourf(X, Y, Z, levels=50, cmap='viridis')
    fig.colorbar(contour, ax=ax2)
    ax2.set_title("Loss Contour")
    ax2.set_xlabel("Direction 1")
    ax2.set_ylabel("Direction 2")

    plt.tight_layout()
    plt.savefig("loss_landscape_plot_" + model_type + ".png")
    plt.show()


if __name__ == '__main__':
    import torch.multiprocessing as mp
    mp.set_start_method('spawn', force=True)

    parser = argparse.ArgumentParser(description="Plot Loss Surface")
    parser.add_argument('--model_path', type=str, required=True, help="Path to the model file")
    parser.add_argument('--model_type', type=str, required=True, choices=['rn20', 'pn20', 'rn56', 'pn56', 'rn110', 'pn110', 'net'], help="Model type (e.g., rn20, pn20, rn56, etc.)")
    parser.add_argument('--dataset', type=str, default='cifar10', help="Dataset name (default: cifar10)")
    parser.add_argument('--x_range', type=float, nargs=2, default=(-2, 2), help="Range for x-axis (default: -1 to 1)")
    parser.add_argument('--y_range', type=float, nargs=2, default=(-2, 2), help="Range for y-axis (default: -1 to 1)")
    parser.add_argument('--steps', type=int, default=20, help="Number of steps for the grid (default: 51)")
    parser.add_argument('--num_workers', type=int, default=1, help="Number of parallel workers (default: number of CPU cores)")

    args = parser.parse_args()
    model_type = args.model_type
    plot_surface(
        # model_path='RESNET-20/v9-cifar10-resnet-20.pth',
        # model_type='rn20',
        model_path=args.model_path,
        model_type=args.model_type,
        dataset=args.dataset,
        x_range=args.x_range,
        y_range=args.y_range,
        steps=args.steps,
        num_workers=args.num_workers
    )