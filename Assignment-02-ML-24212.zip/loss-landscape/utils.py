import torch
import numpy as np

def get_weights(model):
    return [param.data.clone() for param in model.parameters() if param.requires_grad]

def set_weights(model, weights):
    with torch.no_grad():
        for p, w in zip(model.parameters(), weights):
            if p.requires_grad:
                p.data.copy_(w)

def get_random_directions(weights):
    return [torch.randn_like(w) for w in weights], [torch.randn_like(w) for w in weights]

def normalize_direction(direction, weights, ignore='biasbn', norm='filter'):
    # Filter-wise normalization
    normed = []
    for d, w in zip(direction, weights):
        if d.dim() > 1:  # Only normalize filters
            d_norm = torch.norm(d.view(d.shape[0], -1), dim=1, keepdim=True) + 1e-10
            normed_d = d / d_norm.view(-1, *[1]*(d.dim()-1))
        else:
            normed_d = d
        normed.append(normed_d)
    return normed

import torch
import torch.nn as nn
from model_loader import load

def get_net(model_type, dataset, model_file, ngpu=1):
    """
    Loads and initializes the network model.
    """
    model = load(dataset, model_type, model_file)
    if ngpu > 1:
        model = torch.nn.DataParallel(model)
    if torch.cuda.is_available():
        model = model.cuda()
    return model

from dataloader import load_dataset
def get_dataloaders(args):
    """
    Returns the train and test data loaders using the dataset loading utility.
    """
    return load_dataset(
        dataset=args.dataset,
        datapath=args.datapath,
        batch_size=args.batch_size,
        threads=args.threads,
        raw_data=args.raw_data,
        data_split=args.data_split,
        split_idx=args.split_idx,
        trainloader_path=args.trainloader,
        testloader_path=args.testloader
    )

def get_dataloader(args):
    """
    Returns the train and test data loaders using the dataloader module.
    """
    return get_dataloaders(args)

def test_loss_acc(net, criterion, dataloader, use_cuda=True):
    """
    Computes the average loss and accuracy of a model on the given dataloader.
    """
    net.eval()
    total_loss = 0
    correct = 0
    total = 0

    with torch.no_grad():
        for inputs, targets in dataloader:
            if use_cuda:
                inputs, targets = inputs.cuda(), targets.cuda()
            outputs = net(inputs)
            loss = criterion(outputs, targets)
            total_loss += loss.item() * inputs.size(0)
            _, predicted = torch.max(outputs.data, 1)
            correct += predicted.eq(targets).sum().item()
            total += inputs.size(0)

    avg_loss = total_loss / total
    accuracy = 100. * correct / total
    return avg_loss, accuracy

