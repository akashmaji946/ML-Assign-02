export HDF5_USE_FILE_LOCKING=FALSE

####################

mpirun -n 4 python plot_surface.py \
--cuda --mpi --x=-0.5:1.5:401 --model rn20 \
--dir_type states --model_file rn20/v9-cifar10-resnet-20.pth \
--mpi --cuda --dir_type weights --xignore biasbn --xnorm filter \
--yignore biasbn --ynorm filter

mpirun -n 4 python plot_surface.py \
--cuda --mpi --x=-0.5:1.5:401 --model rn56 \
--dir_type states --model_file rn56/v9-cifar10-resnet-56.pth \
--mpi --cuda --dir_type weights --xignore biasbn --xnorm filter \
--yignore biasbn --ynorm filter

mpirun -n 4 python plot_surface.py \
--cuda --mpi --x=-0.5:1.5:401 --model rn110 \
--dir_type states --model_file rn110/v9-cifar10-resnet-110.pth \
--mpi --cuda --dir_type weights --xignore biasbn --xnorm filter \
--yignore biasbn --ynorm filter

######################
mpirun -n 4 python plot_surface.py \
--cuda --mpi --x=-0.5:1.5:401 --model pn20 \
--dir_type states --model_file pn20/v9-cifar10-plainnet-20.pth \
--mpi --cuda --dir_type weights --xignore biasbn --xnorm filter \
--yignore biasbn --ynorm filter

mpirun -n 4 python plot_surface.py \
--cuda --mpi --x=-0.5:1.5:401 --model pn56 \
--dir_type states --model_file pn56/v9-cifar10-plainnet-56.pth \
--mpi --cuda --dir_type weights --xignore biasbn --xnorm filter \
--yignore biasbn --ynorm filter

mpirun -n 4 python plot_surface.py \
--cuda --mpi --x=-0.5:1.5:401 --model pn110 \
--dir_type states --model_file pn110/v9-cifar10-plainnet-110.pth \
--mpi --cuda --dir_type weights --xignore biasbn --xnorm filter \
--yignore biasbn --ynorm filter

